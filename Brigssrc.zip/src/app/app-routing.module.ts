import { Routes } from '@angular/router';
import { AuthComponent } from './layouts/auth/auth.component';
import { AdminComponent } from './layouts/admin/admin.component';


export const AppRoutes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full"
  },
  {
    path : "",
    component : AdminComponent,
    children : [
      {
        path : "dashboard",
        loadChildren : "./dashboard/dashboard.module#DashboardModule",
         
        

      },
      {
        path :"asset",
        loadChildren : "./modules/asset/asset.module#AssetModule",
        
        
      },
      {
        path :"asset-category",
        loadChildren : "./modules/asset-category/asset-category.module#AssetCategoryModule",
        
      },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // },
      // {
      //   path :"",
      //   loadChildren : "",
        
      // }
    ]
  },
  {
    path: "",
    component: AuthComponent,
    children: [
      {
        path: "",
        loadChildren: "./login/login.module#LoginModule"
      }
    ]
  }
];



import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../public service/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email_address: string = null;
  password: string = null;
  newpassword: string = null;
  confirmpassword: string = null;
  sendOTPFlag: boolean;
  forgPass: boolean = false;
  newPassword: boolean;
  new_password: any;
  confirm_password: any;
  otp: any;

  constructor(public authService: AuthenticationService, public router: Router) { }

  ngOnInit() {

  }

  login() {
    this.authService.loginLoader = false;
    let body = new URLSearchParams();
    body.set("emailId", this.email_address);
    body.set("password", this.password);
    body.set("grant_type", "implicit");
    this.authService.login(body);
    console.log(body);

  }





  forgotPassword() {
    if (this.forgPass) {
      this.forgPass = false;
      this.sendOTPFlag = true;
    } else if (!this.forgPass) {
      this.forgPass = true;
      this.sendOTPFlag = false;
    }
  }

  backToLogin() {
    this.forgPass = false;
    this.newPassword = false;
    this.sendOTPFlag = false;


  }

  sendOTP() {
    this.forgPass = true;
    this.sendOTPFlag = true;

  }

  backToForgot() {
    this.forgPass = false;
    this.newPassword = false;
    this.sendOTPFlag = false;
  }

  verifyOTP() {
    this.forgPass = false;
    this.newPassword = true;
    this.sendOTPFlag = false;

  }

  changePass() {
    this.forgPass = false;
    this.sendOTPFlag = false;
    this.newPassword = false;

  }

}  

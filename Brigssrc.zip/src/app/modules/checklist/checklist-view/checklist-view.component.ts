import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checklist-view',
  templateUrl: './checklist-view.component.html',
  styleUrls: ['./checklist-view.component.css']
})
export class ChecklistViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

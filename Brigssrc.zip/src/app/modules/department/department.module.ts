import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DepartmentRoutingModule } from './department-routing.module';
import { DepartmentViewComponent } from './department-view/department-view.component';
import { AddDepartmentComponent } from './department-view/add-department/add-department.component';

@NgModule({
  declarations: [DepartmentViewComponent, AddDepartmentComponent],
  imports: [
    CommonModule,
    DepartmentRoutingModule
  ]
})
export class DepartmentModule { }

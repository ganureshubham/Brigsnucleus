import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manufacturer-view',
  templateUrl: './manufacturer-view.component.html',
  styleUrls: ['./manufacturer-view.component.css']
})
export class ManufacturerViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

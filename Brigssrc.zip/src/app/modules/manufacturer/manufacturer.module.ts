import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManufacturerRoutingModule } from './manufacturer-routing.module';
import { ManufacturerViewComponent } from './manufacturer-view/manufacturer-view.component';
import { AddManufacturerComponent } from './manufacturer-view/add-manufacturer/add-manufacturer.component';

@NgModule({
  declarations: [ManufacturerViewComponent, AddManufacturerComponent],
  imports: [
    CommonModule,
    ManufacturerRoutingModule
  ]
})
export class ManufacturerModule { }

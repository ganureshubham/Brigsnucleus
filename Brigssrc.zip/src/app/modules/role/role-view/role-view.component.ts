import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-view',
  templateUrl: './role-view.component.html',
  styleUrls: ['./role-view.component.css']
})
export class RoleViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleRoutingModule } from './role-routing.module';
import { RoleViewComponent } from './role-view/role-view.component';
import { AddRoleComponent } from './role-view/add-role/add-role.component';

@NgModule({
  declarations: [RoleViewComponent, AddRoleComponent],
  imports: [
    CommonModule,
    RoleRoutingModule
  ]
})
export class RoleModule { }

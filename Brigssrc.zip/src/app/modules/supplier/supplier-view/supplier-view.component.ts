import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-view',
  templateUrl: './supplier-view.component.html',
  styleUrls: ['./supplier-view.component.css']
})
export class SupplierViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

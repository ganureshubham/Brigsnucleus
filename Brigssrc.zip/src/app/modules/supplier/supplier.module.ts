import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SupplierRoutingModule } from './supplier-routing.module';
import { SupplierViewComponent } from './supplier-view/supplier-view.component';
import { AddSupplierComponent } from './supplier-view/add-supplier/add-supplier.component';

@NgModule({
  declarations: [SupplierViewComponent, AddSupplierComponent],
  imports: [
    CommonModule,
    SupplierRoutingModule
  ]
})
export class SupplierModule { }

import { Injectable } from '@angular/core';
import { ConfigurationService } from './configuration.service';
import { RequestOptions, Headers, Response, Http } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import "rxjs/add/operator/map";
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private loginURL = ConfigurationService.baseUrl;
  public isLoggedIn: any;
  public loginLoader: boolean = false;
  redirectUrl: string;

  constructor(private _http: Http, private router: Router) { }

  login(body: URLSearchParams) {
    let headers = new Headers();
    headers.append("Content-Type", "application/x-www-form-urlencoded");
    let options = new RequestOptions({ headers: headers });
    this._http.post(this.loginURL + `authorization/login/`, body.toString(), options).subscribe(
      (response: Response) => {
        if (response) {
          console.log(response.json());
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(response.json()));
          this.isLoggedIn = response.status;
          this.loginLoader = true;
          this.router.navigate(["/dashboard"]);
        }
        else {
          this.isLoggedIn = response.status;
        }
      },
      error => {
        this.loginLoader = true;
      });
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.router.navigate(["/login"]);
  }
}

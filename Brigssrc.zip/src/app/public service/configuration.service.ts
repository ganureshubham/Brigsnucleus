import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConfigurationService {

  constructor() { }

  public static baseUrl = `http://192.168.0.110:4000/`;
}

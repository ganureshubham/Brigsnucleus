import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-asset-document',
  templateUrl: './add-asset-document.component.html',
  styleUrls: ['./add-asset-document.component.css']
})
export class AddAssetDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

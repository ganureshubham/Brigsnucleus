import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-document-view',
  templateUrl: './asset-document-view.component.html',
  styleUrls: ['./asset-document-view.component.css']
})
export class AssetDocumentViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assetmate-layout',
  templateUrl: './assetmate-layout.component.html',
  styleUrls: ['./assetmate-layout.component.css']
})
export class AssetmateLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

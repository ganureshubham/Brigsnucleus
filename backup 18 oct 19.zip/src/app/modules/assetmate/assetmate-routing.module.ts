import { Routes } from '@angular/router';
import { AssetmateViewComponent } from './assetmate-view/assetmate-view.component';
import { AssetmateDetailsComponent } from './assetmate-view/assetmate-details/assetmate-details.component';
import { AssetmateLayoutComponent } from './assetmate-layout/assetmate-layout.component';
import { ViewAssetComponent } from './assetmate-view/view-asset/view-asset.component';
import { AssetAddComponent } from './assetmate-view/asset-add/asset-add.component';

export const AssetmateRoutes: Routes = [
  {
    path: "",
    children: [
      {
        path: "",
        component:AssetmateViewComponent
      }
    ]
  },
 
  {
    path: "",
    children: [
      {
        path: "assetmate-details",
        component: AssetmateDetailsComponent   
      }
    ]
  },
  {
    path: "assetmate-layout",
    component:AssetmateLayoutComponent,
    children: [
      {
        path: "assetmate-details",
        component: AssetmateDetailsComponent   
      },
      {
        path:"add-asset",
        component:AssetAddComponent
      },
      {
        path:"view-asset",
        component:ViewAssetComponent
      }
    ]
  },
  // {
  //   path: "",
  //   children: [
  //     {
  //       path: "asset-add",
  //       component: AddAssetComponent  
  //     }
  //   ]
  // },
];
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-asset-add',
  templateUrl: './asset-add.component.html',
  styleUrls: ['./asset-add.component.css']
})
export class AssetAddComponent implements OnInit {

  navLinks:any[];
  activeLinkIndex = -1;



  constructor(private router:Router) { 
    this.navLinks = [
      {
        label:'Asset',
        path:'/asset',
        index:0
      },
      {
        label:'Checklist',
        path:'/checklist', 
        index:1

      }
    ];
  }

  goto(){
    this.router.navigate(['/assetmate/assetmate-layout/view-asset']);
  }

  ngOnInit() {
    this.router.events.subscribe((res)=>{
      
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));

     })
  }


}

import { Component, OnInit } from '@angular/core';
import { AssetmateService } from '../service/assetmate.service';
import { LoadmoreFlatNode } from './assetmate-details/assetmate-details.component';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-assetmate-view',
  templateUrl: './assetmate-view.component.html',
  styleUrls: ['./assetmate-view.component.css']
})
export class AssetmateViewComponent implements OnInit {
  category:any=[];

  constructor(private assetmateService:AssetmateService,
              private router:Router,
    ) { }

  ngOnInit() {
     this.getList();
  }

  getList(){
    this.assetmateService.getAllRootCateg().subscribe(res=>{
      console.log(res);
      this.category=res.rootCategory;
       
     
      
      
    })
  } 

  categoryDetail(){
    this.router.navigate(['/assetmate/assetmate-layout']);
    
  }

  

}

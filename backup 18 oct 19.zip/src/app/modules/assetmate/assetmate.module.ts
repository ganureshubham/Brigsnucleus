import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssetmateViewComponent } from './assetmate-view/assetmate-view.component';
import { AssetmateDetailsComponent } from './assetmate-view/assetmate-details/assetmate-details.component';
import { RouterModule } from '@angular/router';
import { AssetmateRoutes } from './assetmate-routing.module';
import { MaterialModule } from '../../app.module';
import { FormsModule } from '@angular/forms';
import { AssetModule } from '../asset/asset.module';
import { ViewAssetComponent } from './assetmate-view/view-asset/view-asset.component';
import { AssetmateLayoutComponent } from './assetmate-layout/assetmate-layout.component';
import { AssetAddComponent } from './assetmate-view/asset-add/asset-add.component';

@NgModule({
  declarations: [AssetmateViewComponent, AssetmateDetailsComponent, ViewAssetComponent, AssetmateLayoutComponent, AssetAddComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(AssetmateRoutes),
    MaterialModule,
    FormsModule,
    AssetModule
    
    
    
    
  ],
})
export class AssetmateModule { } 

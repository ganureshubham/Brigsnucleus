import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConfigurationService } from '../../../public service/configuration.service';

@Injectable({
  providedIn: 'root'
})
export class AssetmateService {

  constructor(private httpClient:HttpClient) { }

  getAllRootCateg():Observable<any>{
    return this.httpClient.get<any>(ConfigurationService.baseUrl+`assetHome/allRootCategories`);
  }
}

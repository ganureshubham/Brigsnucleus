import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewCategoryDocumentComponent } from './view-category-document/view-category-document.component';
import { AddCategoryDocumentComponent } from './view-category-document/add-category-document/add-category-document.component';

export const CategoryDocRoutes: Routes = [
  {
    path: "",
    children: [
      {
        path: "",
        component: ViewCategoryDocumentComponent
      }
    ]
  },
  {
    path: "",
    children: [
      {
        path: "add-category-document",
        component: AddCategoryDocumentComponent 
      }
    ]
  },

];

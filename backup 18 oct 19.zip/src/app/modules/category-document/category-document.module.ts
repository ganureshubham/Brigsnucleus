import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewCategoryDocumentComponent } from './view-category-document/view-category-document.component';
import { AddCategoryDocumentComponent } from './view-category-document/add-category-document/add-category-document.component';
import { RouterModule } from '@angular/router';
import { CategoryDocRoutes } from './category-document-routing.module';
import { MaterialModule } from '../../app.module';
import { FormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [ViewCategoryDocumentComponent, AddCategoryDocumentComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(CategoryDocRoutes),
    MaterialModule,
    FormsModule,
    NgxSpinnerModule
  ]
})
export class CategoryDocumentModule { }

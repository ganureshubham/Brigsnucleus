import { TestBed } from '@angular/core/testing';

import { CategoryDocumentService } from './category-document.service';

describe('CategoryDocumentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CategoryDocumentService = TestBed.get(CategoryDocumentService);
    expect(service).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-category-document',
  templateUrl: './add-category-document.component.html',
  styleUrls: ['./add-category-document.component.css']
})
export class AddCategoryDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

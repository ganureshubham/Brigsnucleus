import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { DataSharingService } from '../../../public service/data-sharing.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { CategoryDocumentService } from '../service/category-document.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-view-category-document',
  templateUrl: './view-category-document.component.html',
  styleUrls: ['./view-category-document.component.css']
})
export class ViewCategoryDocumentComponent implements AfterViewInit, OnDestroy {

  loading: boolean;
  public page: number = 0;
  count: number;
  pageNumber = 0;
  totalCount = 0;
  assetData: any = {};

  displayedColumns: string[] = ['documentId', 'title', 'description','Actions'];
  dataSource: MatTableDataSource<CategoryDoc> = new MatTableDataSource();

  //@ViewChild('paidPaginator') paidPaginator: MatPaginator;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  previousSubscription: Subscription;
  upcomingSubscription: Subscription; 
  Router: any; 

  constructor(private http: HttpClient,
    private categoryDocService: CategoryDocumentService,
    private router: Router,
    public dataService: DataSharingService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService  
  ) {

  }

  ngAfterViewInit(): void {
    // Add paginators to datastore here, because we need the view to
    // have created the paginator elements
    this.dataSource.paginator = this.paginator;
    // this.dataSource.filterPredicate = (data: CategoryDoc, filter: string) => {
    //   return data.assetTitle == filter;
    //  };
  }

  ngOnInit() {
    this.getAllCategoryDoc(this.pageNumber);
    
  }

  applyFilter(){}

  ngOnDestroy(): void { } 

 /*********************************************************** Get All Category Documents *******************************************************************/

 getAllCategoryDoc(pageNo:number){
  this.spinner.show();
  setTimeout(() => {
    this.spinner.hide();
  }, 1000);
  this.categoryDocService.getAllCategoryDoc(pageNo).subscribe(res=>{
    console.log(res);
    this.dataSource=res.document;
    this.pageNumber=res.currentPage;
    this.totalCount=res.totalCount;
    
  },
  error=>{
    console.log(error);
    
  })


 }

  /*********************************************************** Page Change *******************************************************************/

  pageChange(pageNo: any) {
    this.loading = true;
    this.page = pageNo.pageIndex;
    this.getAllCategoryDoc(this.page); 
  }


 addDocument(){}
 editDoc(){}
 deleteDoc(){}

}

export interface CategoryDoc {
  documentId: number;
  title: string;
  description: string;
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-checklist',
  templateUrl: './add-checklist.component.html',
  styleUrls: ['./add-checklist.component.css']
})
export class AddChecklistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
